package com.dao;

import java.util.List;

import com.model.Customer;



public interface CustomerDao {
	
	public void addCutomer(Customer customer);
	public List<Customer> getAllCustomer();
	public void deleteCustomer(int id);
	public Customer getCustomerById(int id);
	public Customer getCustomerByCode(String accountNo);
	public void updateCustomer(Customer customer);
	

}
