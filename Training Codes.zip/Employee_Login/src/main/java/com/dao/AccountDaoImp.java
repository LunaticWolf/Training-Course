package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Account;

@Repository
public class AccountDaoImp implements AccountDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void update(Account account) {
		sessionFactory.getCurrentSession().update(account);

	}

	@Override
	public Account find(int id) {
		System.out.println("in dao imp");
		Account account = (Account) sessionFactory.getCurrentSession().load(
				Account.class, id);
		System.out.println(account);
		return account;

	}

	@Override
	public void save(Account account) {
		sessionFactory.getCurrentSession().save(account);
		System.out.println(account);

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Account> getAllAccounts() {
			List<Account> allAccounts = sessionFactory
				.getCurrentSession()
				.createQuery(
						"from Account")
				.list();
		for(Account a: allAccounts){
		System.out.println(a);
		}
		return allAccounts;

	}


	
}
