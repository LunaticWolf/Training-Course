package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Customer;

@Repository
public class CustomerDaoImp implements CustomerDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void addCutomer(Customer customer) {
		System.out.println(customer);
		sessionFactory.getCurrentSession().save(customer);

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> getAllCustomer() {
		return sessionFactory.getCurrentSession().createQuery("FROM Customer")
				.list();
	}

	@Override
	public void deleteCustomer(int id) {
		Customer customer = (Customer) sessionFactory.getCurrentSession().load(
				Customer.class, id);
		sessionFactory.getCurrentSession().delete(customer);

	}

	@Override
	public Customer getCustomerById(int id) {
		Customer customer = (Customer) sessionFactory.getCurrentSession().load(
				Customer.class, id);
		System.out.println(customer);
		return customer;

	}

	@Override
	public Customer getCustomerByCode(String accountNo) {
		System.out.println("Before");
		Customer customer = (Customer) sessionFactory.getCurrentSession().load(
				Customer.class, accountNo);
		System.out.println("After");
		return customer;

	}

	@Override
	public void updateCustomer(Customer customer) {
		sessionFactory.getCurrentSession().update(customer);
		

	}

}
