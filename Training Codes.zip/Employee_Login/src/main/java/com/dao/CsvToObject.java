package com.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.model.Account;

public class CsvToObject {

	public static void main(String[] args) {
String abc=null;
		String csvFile = "C:/Users/temp/Desktop/CSV_File.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";

		try {

			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				//Account account=new Account();

				// use comma as separator
				String[] cols = line.split(cvsSplitBy);

				System.out.println( cols[0]);
				abc=cols[0];

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
}
