package com.dao;

import java.util.List;

import com.model.Account;

public interface AccountDao {

	public void update(Account account );
	public Account find(int id);
	public void save(Account account);
	public List<Account> getAllAccounts();
}
