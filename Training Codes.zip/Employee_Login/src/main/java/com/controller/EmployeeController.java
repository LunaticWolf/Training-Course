package com.controller;

import java.security.Principal;

import org.jboss.logging.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class EmployeeController {

	@SuppressWarnings("unused")
	private static final Logger logger = Logger
			.getLogger(EmployeeController.class);

	public EmployeeController() {
		System.out.println("CustomerController()");
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String welcome(ModelMap model, Principal principal ) {
		String name = principal.getName();
		System.out.println(name);
		model.addAttribute("greetings", name);
		return "redirect:/welcome";
	}
	
	@RequestMapping(value = "/login")
	public String login() {
		return "login";
	}

}