package com.controller;


import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bean.AccountBean;
import com.model.Account;
import com.model.Customer;
import com.service.AccountService;
import com.service.AccountServiceImp;
import com.service.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	CustomerService customerService;

	@Autowired
	AccountService accountService;

	@RequestMapping(value = "/**", method = RequestMethod.GET)
	public ModelAndView welcomeCustomer() {
		return new ModelAndView("welcome");
	}

	@RequestMapping(value = "/AddCustomer", method = RequestMethod.POST)
	public ModelAndView makeCustomer() {
		return new ModelAndView("create");
	}

	@RequestMapping(method = RequestMethod.POST, value = "/CreateCustomer")
	public ModelAndView CreateCustomer(
			@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result) {
		System.out.println(customer);
		if (result.hasErrors()) {
			return new ModelAndView("create", "customer", new Customer());
		} else {
			this.customerService.addCutomer(customer);
			return new ModelAndView("welcome", "Message", "Customer Added");
		}
	}

	@RequestMapping(method = RequestMethod.POST, value = "/Merge")
	public ModelAndView MergeCustomer(
			@ModelAttribute("customer") Customer customer) {
		System.out.println(customer);

		this.customerService.updateCustomer(customer);
		return new ModelAndView("welcome", "Message", "Customer Updated");
	}

	@RequestMapping(method = RequestMethod.POST, value = "/GetAllCustomer")
	public ModelAndView getAllCustomer() {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("customers", customerService.getAllCustomer());
		return new ModelAndView("showAll", model);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/UpdateCustomer")
	public String UpdateCustomer(@RequestParam("id") int id, Model model) {
		model.addAttribute("Customer", this.customerService.getCustomerById(id));
		return "update";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/DeleteCustomer")
	public String DeleteCustomer(@RequestParam("id") int id, Model model) {
		System.out.println(id);
		this.customerService.deleteCustomer(id);
		model.addAttribute("Message", "Customer Deleted");
		return "welcome";
	}

	@RequestMapping(value = "/AddAccount", method = RequestMethod.GET)
	public ModelAndView makeAccount(Model model) {
		model.addAttribute("Account", new Account());
		return new ModelAndView("addAccount");
	}

	@RequestMapping(value = "/AddAccount", method = RequestMethod.POST)
	public ModelAndView make_Account(Model model) {
		model.addAttribute("Account", new Account());
		return new ModelAndView("addAccount");
	}

	@RequestMapping(method = RequestMethod.POST, value = "/CreateCustomerAccount")
	public ModelAndView CreateCustomer(
			@ModelAttribute("account") Account account) {
		System.out.println(" --------- " + account);
		account.setCustomer(customerService.getCustomerById(account.getId()));
		this.accountService.save(account);

		return new ModelAndView("welcome", "Message", "Account Updated");
	}

	@RequestMapping(value = "/transfer", method = RequestMethod.GET)
	public String showAccountTransferForm(Model model) {
		model.addAttribute("accountBean", new AccountBean());
		return "amountTransfer";
	}

	
	@RequestMapping(method = RequestMethod.POST, value = "/transfer")
	public ModelAndView submittedAccountTransferForm(AccountBean accountBean) {
		accountService.transfer(accountBean.getFrom(), accountBean.getTo(),
				accountBean.getMoney());
		return new ModelAndView("welcome", "accountBean", accountBean);
	}
	
/*	@RequestMapping(method = RequestMethod.POST, value = "/updateBalance")
	public ModelAndView updateBalance(@ModelAttribute("account1") Account account1) {
		Account account= accountService.getAccount(account1.getId());
		return new ModelAndView("welcome");
	}*/

	@RequestMapping(value = "/deposit", method = RequestMethod.GET)
	public String showAccountDepositForm(Model model) {
		model.addAttribute("accountBean", new AccountBean());
		return "deposit";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/deposit")
	public ModelAndView submittedAccountDepositedForm(AccountBean accountBean) {
		accountService.deposit(accountBean.getTo(), accountBean.getMoney());
		return new ModelAndView("welcome", "accountBean", accountBean);
	}

	@RequestMapping(value = "/withdraw", method = RequestMethod.GET)
	public String showAccountWithdrawForm(Model model) {
		model.addAttribute("accountBean", new AccountBean());
		return "withdraw";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/withdraw")
	public ModelAndView submittedAccountWithdrawForm(AccountBean accountBean) {
		accountService.withdraw(accountBean.getFrom(), accountBean.getMoney());
		return new ModelAndView("welcome", "accountBean", accountBean);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/ShowAllAccounts")
	public ModelAndView getAllAccount(Model model1) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("accounts", accountService.getAllAccounts());
		System.out.println("CNTRL----- " + accountService.getAllAccounts());
		model1.addAttribute("Account1", new Account());
		return new ModelAndView("showAccount", model);
	}

	/*
	 * @RequestMapping(method = RequestMethod.GET, value ="/pqr") public String
	 * getID((@PathVariable int idAccount account,Model model) {
	 * System.out.println("----------------------------- " + 10 ); Account
	 * account1=accountService.getAccount(10);
	 * System.out.println(accountService.getAccount(10));
	 * model.addAttribute("account",account); return "welcome"; }
	 * 
	 * @RequestMapping(method = RequestMethod.GET, value ="/getId") public
	 * ModelAndView getID1() {
	 * 
	 * return new ModelAndView("idGet"); }
	 */

	/*
	 * @RequestMapping(method = RequestMethod.GET, value = "/pqr/{username}")
	 * public String getUser(@PathVariable String username, Account account,
	 * Model model, Principal principal) { String getuser = principal.getName();
	 * System.out.println("----------------------------- " + username +
	 * getuser); Account account2 = accountService.getAccountUser(getuser);
	 * System.out.println("--------aa rha hai "+
	 * accountService.getAccountUser(getuser));
	 * 
	 * Account account1 = accountService.getAccount(id);
	 * System.out.println(accountService.getAccount(id));
	 * model.addAttribute("ACC", account);
	 * 
	 * return "welcome"; }
	 * 
	 * @RequestMapping(method = RequestMethod.GET, value = "/getUser") public
	 * ModelAndView getID1() {
	 * 
	 * return new ModelAndView("idGet"); }
	 */

}
