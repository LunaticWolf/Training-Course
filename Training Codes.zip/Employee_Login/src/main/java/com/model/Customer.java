package com.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


@Table(name="customer_bank")
@Entity
public class Customer {

	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int id;
	
	//@Column(unique=true)
	private String accountNo;
	
	//@Column(unique=true)
	private String userName;
	
	@Column
	@NotEmpty
	private String password;
	@Column
	@NotEmpty(message="first name can not be empty")
	private String firstName;
	@Column
	@NotEmpty(message="last name can not be empty")
	private String lastName;
	@Column
	@NotEmpty(message="Address can not be empty")
	private String permanentAddress;
	private String temporaryAddress;
	@Column
	@NotEmpty(message="Pincode can not be empty")
	private String pincode;
	private String contactNo;
	private String email;
	private String createdBy;
	private int initialBalance;
	private String aiflag;
	
	
	@OneToOne(cascade=CascadeType.ALL)
	private Account account;
	

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}	

	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getPermanentAddress() {
		return permanentAddress;
	}
	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}
	public String getTemporaryAddress() {
		return temporaryAddress;
	}
	public void setTemporaryAddress(String temporaryAddress) {
		this.temporaryAddress = temporaryAddress;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getAiflag() {
		return aiflag;
	}
	public void setAiflag(String aiflag) {
		this.aiflag = aiflag;
	}
	public int getInitialBalance() {
		return initialBalance;
	}
	public void setInitialBalance(int initialBalance) {
		this.initialBalance = initialBalance;
	}
	
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", userName=" + userName + ", password="
				+ password + ", accountNo=" + accountNo + ", firstName="
				+ firstName + ", lastName=" + lastName + ", permanentAddress="
				+ permanentAddress + ", temporaryAddress=" + temporaryAddress
				+ ", pincode=" + pincode + ", contactNo=" + contactNo
				+ ", email=" + email + ", createdBy=" + createdBy
				+ ", initialBalance=" + initialBalance + ", aiflag=" + aiflag
				+ "]";
	}
	
	
	

	
}
