package com.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "account_Customer")
public class Account {

	@Id
	private int id;

	private String accountNo;

	private double balance;

	private String accountType;
	
	@JoinColumn(name = "id", referencedColumnName = "id")
	@OneToOne
	private Customer customer;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public Account(){
		id=0;
		accountNo=null;
		balance=0.0;
		accountType=null;
	}

	
	@Override
	public String toString() {
		return "Account [id=" + id + ", accountNO=" + accountNo + ", balance="
				+ balance + ", accountType=" + accountType + ", customer="
				+ customer + "]";
	}

}
