package com.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.AccountDao;
import com.model.Account;


@Service
public class AccountServiceImp implements AccountService {

	@Autowired
	AccountDao accountDao;
	
	@Override
	@Transactional
	public void transfer(int from, int to, double amount) {
		
		Account fromAccount=accountDao.find(from);
		Account toAccount=accountDao.find(to);
		
		fromAccount.setBalance(fromAccount.getBalance()-amount);
		toAccount.setBalance(toAccount.getBalance()+amount);
		
		accountDao.update(fromAccount);
		accountDao.update(toAccount);
	}

	
	@Override
	@Transactional
	public void deposit(int id, double amount) {
		
		Account account=accountDao.find(id);
		account.setBalance(account.getBalance()+amount);
		accountDao.update(account);
	}
	
	

	@Override
	@Transactional
	public void withdraw(int id, double amount) {
		
		Account account=accountDao.find(id);
		account.setBalance(account.getBalance()-amount);
		accountDao.update(account);
	}
	
	
	@Override
	@Transactional
	public Account getAccount(int id) {	
		System.out.println("-hello bharti--------"+id);
		return accountDao.find(id);
	}


	@Override
	@Transactional
	public void update(Account account) {
		accountDao.update(account);	
	}

	@Override
	@Transactional
	public void save(Account account) {
		accountDao.save(account);		
		System.out.println(" --- Servicve  " +  account);
	}

	@Override
	@Transactional
	public List<Account> getAllAccounts() {	

		return accountDao.getAllAccounts();
		
	}

}
