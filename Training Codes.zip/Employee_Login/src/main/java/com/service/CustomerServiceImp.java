package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.CustomerDao;
import com.model.Customer;


@Service
@Transactional
public class CustomerServiceImp implements CustomerService {

	@Autowired
	CustomerDao customerDao;
	
	@Override
	public void addCutomer(Customer customer) {
		customerDao.addCutomer(customer);
		
	}

	@Override
	public List<Customer> getAllCustomer() {
		System.out.println(customerDao.getAllCustomer());
		return customerDao.getAllCustomer();
		
	}

	@Override
	public void deleteCustomer(int id) {
		customerDao.deleteCustomer(id);
		
	}

	@Override
	public Customer getCustomerById(int id) {
		
		return customerDao.getCustomerById(id);
	}

	@Override
	public Customer getCustomerByCode(String accountNo) {
	
		return customerDao.getCustomerByCode(accountNo);
	}

	@Override
	public void updateCustomer(Customer customer) {
	customerDao.updateCustomer(customer);
		
	}
	
	

}
