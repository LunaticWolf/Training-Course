package com.service;

import java.util.List;

import com.model.Account;

public interface AccountService {

	public void transfer(int from, int to, double amount);
	public void deposit(int id, double amount);
	public void withdraw(int id, double amount);
	public Account getAccount(int id);
	public void update(Account account);
	public void save(Account account);
	public List<Account> getAllAccounts();
	
}
