package controller;

public class Validation {
	

	boolean isValidName(String name) {
		if (name.matches("^[a-zA-Z0-9]+") && name.length()<=30) {
			return false;
		} else {
			return true;
		}

	}
	
boolean isValidCustomer_code(String Customer_code) {
		
		if (Customer_code.length() == 6) {
			return true;

		} else {
			return false;
		}
	}

	boolean isValidPincode(String pincode) {
		
		if (pincode.length() == 6) {
			return true;

		} else {
			return false;
		}
	}
	boolean isvalidEmail(String email){
		if(email.contains("@")&&email.contains(".com")){
			return true;
		}
		else{
			return false;
		}
		
	}
	boolean isValidRecordStatus(String recordstatus){
		if(recordstatus.equals("N")||recordstatus.equals("M")||recordstatus.equals("D")||recordstatus.equals("A")||recordstatus.equals("R")){
			return true;
			
		}
		else{
			return true;
		}
	}
	boolean isValidActiveinActiveflag(String activeinactiveflag){
		if(activeinactiveflag.equals("A")||activeinactiveflag.equals("I")){
			return true;
			
		}
		else{
			return true;
		}
	}

}
