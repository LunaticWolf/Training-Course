package com.nu.bookapp.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nu.bookapp.model.persistance.Book;
import com.nu.bookapp.model.persistance.BookDao;
import com.nu.bookapp.model.persistance.BookDaoImpl;
import com.nu.bookapp.model.persistance.exceptions.DaoException;
import com.nu.bookapp.model.service.BookService;
import com.nu.bookapp.model.service.BookServiceImpl;

public class AddBookController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection ;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		connection= (Connection)config.getServletContext().getAttribute("connection");
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/jsp/add.jsp").forward(request,
				response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException { 
		// TODO Auto-generated method stub
		String isbn = request.getParameter("isbn");
		String author = request.getParameter("author");
		String title = request.getParameter("title");
		Float price = Float.parseFloat(request.getParameter("price"));
		Book book = null;
		BookDao bookDao = new BookDaoImpl(connection);
		BookService bookService = new BookServiceImpl(bookDao);

		try {
			book = new Book(isbn, title, author, price);
			bookService.addBook(book);
			request.setAttribute("book", book);
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/jsp/success.jsp");
			rd.forward(request, response);
		} catch (DaoException e) {
			e.printStackTrace();
		}

	}

}
