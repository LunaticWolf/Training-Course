package com.nu.bookapp.model.persistance.exceptions;

public class DaoException extends Exception {

	private static final long serialVersionUID = 8202122674791761752L;

	public DaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
