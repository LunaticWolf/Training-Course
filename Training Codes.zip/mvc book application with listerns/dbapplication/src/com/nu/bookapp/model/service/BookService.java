package com.nu.bookapp.model.service;

import java.util.List;

import com.nu.bookapp.model.persistance.Book;
import com.nu.bookapp.model.persistance.exceptions.BookNotFoundException;
import com.nu.bookapp.model.persistance.exceptions.DaoException;

public interface BookService {
	//Business method
	//SL =BL + CCC + constraints
	/*
	 * CCC; tx sec logging caching
	 */
	public void addBook(Book book)throws DaoException;
	public List<Book> getAllBooks()throws DaoException;
	public Book getBookById()throws DaoException, BookNotFoundException;
}
