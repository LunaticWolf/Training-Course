package com.nu.bookapp.model.persistance;

import java.util.List;

import com.nu.bookapp.model.persistance.exceptions.BookNotFoundException;
import com.nu.bookapp.model.persistance.exceptions.DaoException;
import com.nu.bookapp.model.persistance.exceptions.HibernateException;

public class BookDaoImplUsingHibenate implements BookDao {

	@Override
	public void addBook(Book book) throws DaoException {
		try{
			
			//
			throw new HibernateException();
		}catch(HibernateException e){
			throw new DaoException("some hib hell" , e);
		}
	}

	@Override
	public List<Book> getAllBooks() throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book getBookById() throws DaoException, BookNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
