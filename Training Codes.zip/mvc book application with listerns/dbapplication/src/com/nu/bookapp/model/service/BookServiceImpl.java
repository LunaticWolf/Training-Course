package com.nu.bookapp.model.service;

import java.util.List;

import com.nu.bookapp.model.persistance.Book;
import com.nu.bookapp.model.persistance.BookDao;
import com.nu.bookapp.model.persistance.exceptions.BookNotFoundException;
import com.nu.bookapp.model.persistance.exceptions.DaoException;

public class BookServiceImpl implements BookService{

	private BookDao dao;
	
	public BookServiceImpl(BookDao dao){
		this.dao=dao;
	}
	
	@Override
	public void addBook(Book book) throws DaoException {
		// sec profiling
		dao.addBook(book);
	}

	@Override
	public List<Book> getAllBooks() throws DaoException {
		
		return null;
	}

	@Override
	public Book getBookById() throws DaoException, BookNotFoundException {
		
		return null;
	}

}
