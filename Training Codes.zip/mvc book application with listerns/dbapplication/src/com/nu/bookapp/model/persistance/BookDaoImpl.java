package com.nu.bookapp.model.persistance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.nu.bookapp.model.persistance.exceptions.BookNotFoundException;
import com.nu.bookapp.model.persistance.exceptions.DaoException;

public class BookDaoImpl implements BookDao {

	private Connection connection;

	public BookDaoImpl(Connection connection) {
		this.connection = connection;
	}

	@Override
	public void addBook(Book book) throws DaoException {
		

		PreparedStatement pstmt;
		try {
			pstmt = connection
					.prepareStatement("insert into BOOKS(isbn, author, title, price)values	(?,?,?,?)");
		
			pstmt.setString(1, book.getIsbn());
			pstmt.setString(2, book.getAuthor());
			pstmt.setString(3, book.getTitle());
			pstmt.setFloat(4, book.getPrice());
			pstmt.executeUpdate();
		
		
		} catch (SQLException e) {
			throw new DaoException("some jdbc problem",e);
		}

		
		

	}

	@Override
	public List<Book> getAllBooks() throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book getBookById() throws DaoException, BookNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
