package com.nu.bookapp.model.persistance.exceptions;

public class HibernateException extends Exception{

}
