package com.demo;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.SingleThreadModel;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/*
 * 
 *  Servlet : controller layer in MVC design pattern
 *  	java code===> html
 *  
 *  JSP: for view layer
 *   look like html====> java code====> html
 *   
 *   				equ servlet
 *   
 *   implements SingleThreadModel : is a old deprecated concept not supported by tomcat now a day!
 */
public class Hello extends HttpServlet  {
	private static final long serialVersionUID = 1L;
    
    public Hello() { 
    	System.out.println("ctr is called....");
    }

	
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) 
					throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("hello...");
	}


}
