package com.bookapp.model.persistance;
public enum BookType {
	IT, MGT
}