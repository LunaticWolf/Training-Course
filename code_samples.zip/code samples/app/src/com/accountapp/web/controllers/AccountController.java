package com.accountapp.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.accountapp.model.service.BankFacade;
import com.accountapp.web.formbeans.AccountForm;

@Controller
@RequestMapping
public class AccountController {

	@Autowired
	private BankFacade bankFacade;
	
	@RequestMapping(method=RequestMethod.GET, value="transfer")
	public String showAccountTransferForm(ModelMap map){
		
		map.addAttribute("accountForm",new AccountForm());
		return "accountform";
	}
	
	@RequestMapping(method=RequestMethod.POST, value="transfer")
	public ModelAndView submittedAccountTransferForm(AccountForm accountForm){
	
		bankFacade.transfer(accountForm.getFrom(), accountForm.getTo(), accountForm.getMoney());
		return new ModelAndView("transfersuccess" ,"accountForm",accountForm);
	}	
}







