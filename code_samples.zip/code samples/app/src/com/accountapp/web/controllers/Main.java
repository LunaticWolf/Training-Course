package com.accountapp.web.controllers;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accountapp.model.service.BankFacade;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		
		BankFacade bankFacade=ctx.getBean("as",BankFacade.class);
		
		bankFacade.transfer(1, 2, 10);
		
	}
}
