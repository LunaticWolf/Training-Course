package com.accountapp.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.accountapp.model.persistance.Account;
import com.accountapp.model.persistance.AccountDao;

@Service
@Transactional(isolation=Isolation.DEFAULT, readOnly=true, propagation=Propagation.SUPPORTS)
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountDao dao;
	
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public void transfer(int from, int to, int amount) {
		Account  fromAccount=dao.find(from);
		Account toAccount=dao.find(to);
		fromAccount.setBalance(fromAccount.getBalance()-amount);
		toAccount.setBalance(toAccount.getBalance()+amount);
		
		dao.update(fromAccount);
		dao.update(toAccount);
		
	}

	@Override
	public void deposit(int id, double amount) {
		Account account=dao.find(id);
		account.setBalance(account.getBalance()+amount);
		dao.update(account);
	}

	@Override
	public Account getAccount(int id) {
		// TODO Auto-generated method stub
		return dao.find(id);
	}

}
