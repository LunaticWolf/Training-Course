package com.accountapp.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.accountapp.model.persistance.Record;
import com.accountapp.model.persistance.RecordDao;

@Service
@Transactional
public class RecordServiceImpl implements RecordService{

	@Autowired
	private RecordDao dao;
	
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public void addRecord(Record record) {
		dao.addRecord(record);
	}
}
