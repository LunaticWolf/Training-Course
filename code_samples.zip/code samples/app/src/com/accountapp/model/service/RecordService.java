package com.accountapp.model.service;

import com.accountapp.model.persistance.Record;

public interface RecordService {
	public void addRecord(Record record);
}
