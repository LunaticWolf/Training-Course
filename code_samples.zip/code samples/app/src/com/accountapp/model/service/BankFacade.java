package com.accountapp.model.service;

import com.accountapp.model.persistance.Account;

public interface BankFacade {
	public void transfer(int from, int to, int amout);
	public void deposit(int id, double amount);
	public Account getAccount(int id);
}
