package com.accountapp.model.service;

public interface EmailService {
	public void sendEmail(String emailId);
}
