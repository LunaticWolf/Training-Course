package com.accountapp.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.accountapp.model.persistance.Account;
import com.accountapp.model.persistance.Record;
@Service(value="as")
@Transactional(propagation=Propagation.SUPPORTS, readOnly=true)
public class BankFacadeImpl implements BankFacade {

	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private AccountService accountService;
	
	@Autowired
	private RecordService recordService;
	
	@Transactional(isolation=Isolation.DEFAULT,
			propagation=Propagation.REQUIRED, timeout=20)
	@Loggable
	@Override
	public void transfer(int from, int to, int amout) {
		
		accountService.transfer(from, to, amout);
		
		if(emailService!=null)
			emailService.sendEmail("r@r.com");
		
		recordService.addRecord(new Record(from, to));
		
		/*if(1==1)
			throw new NullPointerException();*/
	}

	@Override
	public void deposit(int id, double amount) {
		
	}

	@Override
	public Account getAccount(int id) {
		return null;
	}

}
