package com.accountapp.model.persistance;

public interface RecordDao {
	public void addRecord(Record record);
}
