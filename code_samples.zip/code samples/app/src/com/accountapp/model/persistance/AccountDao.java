package com.accountapp.model.persistance;

public interface AccountDao {
	public void update(Account account);
	public Account find(int id);
}
