package com.accountapp.model.persistance;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class RecordDaoImpl implements RecordDao{

	@PersistenceContext
	private EntityManager em;
	@Override
	public void addRecord(Record record) {
		em.persist(record);
	}

}
